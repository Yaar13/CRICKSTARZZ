//
//  main.swift
//  CrickStar
//
//  Created by admin on 2019-06-15.
//  Copyright © 2019 CrickStar. All rights reserved.
//

import Foundation

var player1: Player = Player()

player1.personId = 1

player1.personName = "Sehwag"

player1.personGender = Gender.Male

player1.personSponsor = "Sahara"

player1.playerType = PlayerType.Batsman

player1.countryName = "India"

player1.playerJerseyNo = 95

player1.inPlaying = true



var player2: Player = Player()

player2.personId = 2

player2.personName = "Sachin"

player2.personGender = Gender.Male

player2.personSponsor = "Sahara"

player2.playerType = PlayerType.Batsman

player2.countryName = "India"

player2.playerJerseyNo = 94

player2.inPlaying = true





var player3: Player = Player()

player3.personId = 3

player3.personName = "Kohli"

player3.personGender = Gender.Male

player3.personSponsor = "Sahara"

player3.playerType = PlayerType.Batsman

player3.countryName = "India"

player3.playerJerseyNo = 96

player3.inPlaying = true



var player4: Player = Player()

player4.personId = 4

player4.personName = "Dhoni"

player4.personGender = Gender.Male

player4.personSponsor = "Sahara"

player4.playerType = PlayerType.Batsman

player4.countryName = "India"

player4.playerJerseyNo = 99

player4.inPlaying = true





var player5: Player = Player()

player5.personId = 5

player5.personName = "Shami"

player5.personGender = Gender.Male

player5.personSponsor = "Sahara"

player5.playerType = PlayerType.Bowler

player5.countryName = "India"

player5.playerJerseyNo = 90

player5.inPlaying = true



var player6: Player = Player()

player6.personId = 6

player6.personName = "Hayden"

player6.personGender = Gender.Male

player6.personSponsor = "Alinta energy"

player6.playerType = PlayerType.Batsman

player6.countryName = "Australia"

player6.playerJerseyNo = 85

player6.inPlaying = true





var player7: Player = Player()

player7.personId = 7

player7.personName = "Gilchrist"

player7.personGender = Gender.Male

player7.personSponsor = "Alinta Energy"

player7.playerType = PlayerType.Batsman

player7.countryName = "Australia"

player7.playerJerseyNo = 86

player7.inPlaying = true





var player8: Player = Player()

player8.personId = 8

player8.personName = "Ponting"

player8.personGender = Gender.Male

player8.personSponsor = "Alinta Energy"

player8.playerType = PlayerType.Batsman

player8.countryName = "Australia"

player8.playerJerseyNo = 87

player8.inPlaying = true



var player9: Player = Player()

player9.personId = 9

player9.personName = "maxwell"

player9.personGender = Gender.Male

player9.personSponsor = "Alinta Energy"

player9.playerType = PlayerType.Batsman

player9.countryName = "India"

player9.playerJerseyNo = 88

player9.inPlaying = true





var player10: Player = Player()

player10.personId = 10

player10.personName = "Brett lee"

player10.personGender = Gender.Male

player10.personSponsor = "Alinta Energy"

player10.playerType = PlayerType.Bowler

player10.countryName = "Australia"

player10.playerJerseyNo = 89

player10.inPlaying = true



var player11: Player = Player()

player11.personId = 11

player11.personName = "Gibbs"

player11.personGender = Gender.Male

player11.personSponsor = "Asix"

player11.playerType = PlayerType.Batsman

player11.countryName = "South Africa"

player11.playerJerseyNo = 75

player11.inPlaying = true





var player12: Player = Player()

player12.personId = 12

player12.personName = "dekock"

player12.personGender = Gender.Male

player12.personSponsor = "Asix"

player12.playerType = PlayerType.Batsman

player12.countryName = "South Africa"

player12.playerJerseyNo = 76

player12.inPlaying = true



var player13: Player = Player()

player13.personId = 13

player13.personName = "Amla"

player13.personGender = Gender.Male

player13.personSponsor = "Asix"

player13.playerType = PlayerType.Batsman

player13.countryName = "South Africa"

player13.playerJerseyNo = 77

player13.inPlaying = true



var player14: Player = Player()

player14.personId = 14

player14.personName = "Devilers"

player14.personGender = Gender.Male

player14.personSponsor = "Asix"

player14.playerType = PlayerType.Batsman

player14.countryName = "Australia"

player14.playerJerseyNo = 78

player14.inPlaying = true





var player15: Player = Player()

player15.personId = 15

player15.personName = "Andrew Nill"

player15.personGender = Gender.Male

player15.personSponsor = "Asix"

player15.playerType = PlayerType.Bowler

player15.countryName = "Australia"

player15.playerJerseyNo = 79

player15.inPlaying = true





var player16: Player = Player()

player16.personId = 16

player16.personName = "Farhat"

player16.personGender = Gender.Male

player16.personSponsor = "Pepsi"

player16.playerType = PlayerType.Batsman

player16.countryName = "PAkistan"

player16.playerJerseyNo = 65

player16.inPlaying = true





var player17: Player = Player()

player17.personId = 17

player17.personName = "Hameed"

player17.personGender = Gender.Male

player17.personSponsor = "Pepsi"

player17.playerType = PlayerType.Batsman

player17.countryName = "Pakistan"

player17.playerJerseyNo = 66

player17.inPlaying = true



var player18: Player = Player()

player18.personId = 18

player18.personName = "Shoib Malik"

player18.personGender = Gender.Male

player18.personSponsor = "Pepsi"

player18.playerType = PlayerType.Batsman

player18.countryName = "Pakistan"

player18.playerJerseyNo = 67

player18.inPlaying = true



var player19: Player = Player()

player19.personId = 19

player19.personName = "Sarfaraz"

player19.personGender = Gender.Male

player19.personSponsor = "Pepsi"

player19.playerType = PlayerType.Batsman

player19.countryName = "Pakistan"

player19.playerJerseyNo = 68

player19.inPlaying = true



var player20: Player = Player()

player20.personId = 20

player20.personName = "Shoib Akhtar"

player20.personGender = Gender.Male

player20.personSponsor = "Pepsi"

player20.playerType = PlayerType.Bowler

player20.countryName = "Pakistan"

player20.playerJerseyNo = 69

player20.inPlaying = true



var player21: Player = Player()

player21.personId = 21

player21.personName = "Sanath Jayasuriya"

player21.personGender = Gender.Male

player21.personSponsor = "Dialog"

player21.playerType = PlayerType.Batsman

player21.countryName = "Sri Lanka"

player21.playerJerseyNo = 55

player21.inPlaying = true



var player22: Player = Player()

player22.personId = 22

player22.personName = "Marvan Attapattu"

player22.personGender = Gender.Male

player22.personSponsor = "Dialog"

player22.playerType = PlayerType.Batsman

player22.countryName = "Sri Lanka"

player22.playerJerseyNo = 56

player22.inPlaying = true



var player23: Player = Player()

player23.personId = 23

player23.personName = "Sangakara"

player23.personGender = Gender.Male

player23.personSponsor = "Dialog"

player23.playerType = PlayerType.Batsman

player23.countryName = "Sri Lanka"

player23.playerJerseyNo = 57

player23.inPlaying = true





var player24: Player = Player()

player24.personId = 24

player24.personName = "Mahila Jayavardne"

player24.personGender = Gender.Male

player24.personSponsor = "Dialog"

player24.playerType = PlayerType.Batsman

player24.countryName = "Sri Lanka"

player24.playerJerseyNo = 58

player24.inPlaying = true



var player25: Player = Player()

player25.personId = 25

player25.personName = "Lasith Malinga"

player25.personGender = Gender.Male

player25.personSponsor = "Dialog"

player25.playerType = PlayerType.Bowler

player25.countryName = "Sri Lanka"

player25.playerJerseyNo = 59

player25.inPlaying = true





var player26: Player = Player()

player26.personId = 26

player26.personName = "Marcus Trescothik"

player26.personGender = Gender.Male

player26.personSponsor = "New Balance"

player26.playerType = PlayerType.Batsman

player26.countryName = "England"

player26.playerJerseyNo = 45

player26.inPlaying = true





var player27: Player = Player()

player27.personId = 27

player27.personName = "Andrew Strauss"

player27.personGender = Gender.Male

player27.personSponsor = "New Balance"

player27.playerType = PlayerType.Batsman

player27.countryName = "England"

player27.playerJerseyNo = 46

player27.inPlaying = true



var player28: Player = Player()

player28.personId = 28

player28.personName = "Joe Root"

player28.personGender = Gender.Male

player28.personSponsor = "New Balance"

player28.playerType = PlayerType.Batsman

player28.countryName = "England"

player28.playerJerseyNo = 47

player28.inPlaying = true



var player29: Player = Player()

player29.personId = 29

player29.personName = "Buttler"

player29.personGender = Gender.Male

player29.personSponsor = "New Balance"

player29.playerType = PlayerType.Batsman

player29.countryName = "England"

player29.playerJerseyNo = 48

player29.inPlaying = true



var player30: Player = Player()

player30.personId = 30

player30.personName = "Panesar"

player30.personGender = Gender.Male

player30.personSponsor = "New Balance"

player30.playerType = PlayerType.Batsman

player30.countryName = "England"

player30.playerJerseyNo = 49

player30.inPlaying = true









var umpire01: Umpire = Umpire()

umpire01.personId = 01

umpire01.personName = "Alim Dar"

umpire01.personGender = Gender.Male

umpire01.personSponsor = "Pakistan"

umpire01.umpireType = UmpireType.MatchOfficial

umpire01.numberOfMatches = 224

umpire01.umpireRank = 1



var umpire02: Umpire = Umpire()

umpire02.personId = 02

umpire02.personName = "David shephard"

umpire02.personGender = Gender.Male

umpire02.personSponsor = "England"

umpire02.umpireType = UmpireType.MatchOfficial

umpire02.numberOfMatches = 125

umpire02.umpireRank = 5





var umpire03: Umpire = Umpire()

umpire03.personId = 03

umpire03.personName = "Ian Gould"

umpire03.personGender = Gender.Male

umpire03.personSponsor = "Newzealand"

umpire03.umpireType = UmpireType.MatchOfficial

umpire03.numberOfMatches = 201

umpire03.umpireRank = 3





var umpire04: Umpire = Umpire()

umpire04.personId = 04

umpire04.personName = "kumar Dharmasena"

umpire04.personGender = Gender.Male

umpire04.personSponsor = "Sri Lanka"

umpire04.umpireType = UmpireType.MatchOfficial

umpire04.numberOfMatches = 120

umpire04.umpireRank = 4





var umpire05: Umpire = Umpire()

umpire05.personId = 05

umpire05.personName = "Nigel Llong"

umpire05.personGender = Gender.Male

umpire05.personSponsor = "England"

umpire05.umpireType = UmpireType.MatchOfficial

umpire05.numberOfMatches = 190

umpire05.umpireRank = 2


var coach1: Coach = Coach()
coach1.personId = 111
coach1.personName = "Ravi Shastri"
coach1.personSponsor = "Nike"
coach1.personGender = Gender.Male
coach1.coachingCountry = "India"
coach1.coachType = CoachType.HeadCoach
coach1.coachExperience = 5

var coach2: Coach = Coach()
coach2.personId = 112
coach2.personName = "gary kirsten"
coach2.personSponsor = "puma"
coach2.personGender = Gender.Male
coach2.coachingCountry = "SouthAfrica"
coach2.coachType = CoachType.HeadCoach
coach2.coachExperience = 7

var coach3: Coach = Coach()
coach3.personId = 112
coach3.personName = "gary kirsten"
coach3.personSponsor = "puma"
coach3.personGender = Gender.Male
coach3.coachingCountry = "SouthAfrica"
coach3.coachType = CoachType.HeadCoach
coach3.coachExperience = 7

var coach4: Coach = Coach()
coach4.personId = 112
coach4.personName = "gary kirsten"
coach4.personSponsor = "puma"
coach4.personGender = Gender.Male
coach4.coachingCountry = "SouthAfrica"
coach4.coachType = CoachType.HeadCoach
coach4.coachExperience = 7

var coach5: Coach = Coach()
coach5.personId = 112
coach5.personName = "gary kirsten"
coach5.personSponsor = "puma"
coach5.personGender = Gender.Male
coach5.coachingCountry = "SouthAfrica"
coach5.coachType = CoachType.HeadCoach
coach5.coachExperience = 7

var coach6: Coach = Coach()
coach6.personId = 112
coach6.personName = "Rutherford"
coach6.personSponsor = "natwest"
coach6.personGender = Gender.Male
coach6.coachingCountry = "England"
coach6.coachType = CoachType.HeadCoach
coach6.coachExperience = 7

var team1: Team = Team()
team1.teamCountry = "India"
team1.teamRank = 1
team1.players = [player1,player2,player3,player4,player5]
team1.teamHeadCoach = coach1.personName

var team2: Team = Team()
team2.teamCountry = "Australia"
team2.teamRank = 2
team2.players = [player6,player7,player8,player9,player10]
team2.teamHeadCoach = coach1.personName


var team3: Team = Team()
team3.teamCountry = "South Africa"
team3.teamRank = 3
team3.players = [player11,player12,player13,player14,player15]
team3.teamHeadCoach = coach1.personName


var team4: Team = Team()
team4.teamCountry = "Pakistan"
team4.teamRank = 4
team4.players = [player16,player17,player18,player19,player20]
team4.teamHeadCoach = coach1.personName


var team5: Team = Team()
team5.teamCountry = "Srilanka"
team5.teamRank = 5
team5.players = [player21,player22,player23,player24,player25]
team5.teamHeadCoach = coach1.personName


var team6: Team = Team()
team6.teamCountry = "England"
team6.teamRank = 6
team6.players = [player26,player27,player28,player29,player30]
team6.teamHeadCoach = coach6.personName





var worldMatch1: WorldCup = WorldCup()
worldMatch1.matchNumber = 1
worldMatch1.matchType = MatchType.PlayOffs
worldMatch1.Team1 = team1
worldMatch1.Team2 = team2
worldMatch1.oversFormat = OversFormat.FiftyOvers
worldMatch1.Team1Score = 250
worldMatch1.Team2Score = 159
worldMatch1.ballType = BallType.WhiteBall

var worldMatch2: WorldCup = WorldCup()

worldMatch2.matchNumber = 2

worldMatch2.matchType = MatchType.PlayOffs

worldMatch2.Team1 = team3

worldMatch2.Team2 = team4

worldMatch2.oversFormat = OversFormat.FiftyOvers

worldMatch2.Team1Score = 225          //team 4 wins here

worldMatch2.Team2Score = 226

worldMatch2.ballType = BallType.WhiteBall



var worldMatch3: WorldCup = WorldCup()

worldMatch3.matchNumber = 3

worldMatch3.matchType = MatchType.PlayOffs

worldMatch3.Team1 = team5

worldMatch3.Team2 = team6

worldMatch3.oversFormat = OversFormat.FiftyOvers

worldMatch3.Team1Score = 313         //team 5 wins here

worldMatch3.Team2Score = 310

worldMatch3.ballType = BallType.WhiteBall





var worldMatch4: WorldCup = WorldCup()

worldMatch4.matchNumber = 4

worldMatch4.matchType = MatchType.PlayOffs

worldMatch4.Team1 = team1

worldMatch4.Team2 = team4

worldMatch4.oversFormat = OversFormat.FiftyOvers

worldMatch4.Team1Score = 220                //team 1 wins here

worldMatch4.Team2Score = 210

worldMatch4.ballType = BallType.WhiteBall





var worldMatch5: WorldCup = WorldCup()

worldMatch5.matchNumber = 5

worldMatch5.matchType = MatchType.PlayOffs

worldMatch5.Team1 = team2

worldMatch5.Team2 = team3

worldMatch5.oversFormat = OversFormat.FiftyOvers

worldMatch5.Team1Score = 302               //team 2 wins here

worldMatch5.Team2Score = 257

worldMatch5.ballType = BallType.WhiteBall





var worldMatch6: WorldCup = WorldCup()

worldMatch6.matchNumber = 6

worldMatch6.matchType = MatchType.PlayOffs

worldMatch6.Team1 = team5

worldMatch6.Team2 = team3

worldMatch6.oversFormat = OversFormat.FiftyOvers

worldMatch6.Team1Score = 250          //team 5 wins here

worldMatch6.Team2Score = 159

worldMatch6.ballType = BallType.WhiteBall





// Quarter finals starts here





var worldMatch7: WorldCup = WorldCup()

worldMatch7.matchNumber = 7

worldMatch7.matchType = MatchType.quarterfinals

worldMatch7.Team1 = team1

worldMatch7.Team2 = team4

worldMatch7.oversFormat = OversFormat.FiftyOvers

worldMatch7.Team1Score = 333     //team 1 wins here

worldMatch7.Team2Score = 312

worldMatch7.ballType = BallType.WhiteBall



var worldMatch8: WorldCup = WorldCup()

worldMatch8.matchNumber = 8

worldMatch8.matchType = MatchType.quarterfinals

worldMatch8.Team1 = team5  //team 5 wins here

worldMatch8.Team2 = team3

worldMatch8.oversFormat = OversFormat.FiftyOvers

worldMatch8.Team1Score = 312     // team 5 wins here

worldMatch8.Team2Score = 309

worldMatch8.ballType = BallType.WhiteBall





var worldMatch9: WorldCup = WorldCup()

worldMatch9.matchNumber = 9

worldMatch9.matchType = MatchType.quarterfinals

worldMatch9.Team1 = team2

worldMatch9.Team2 = team6

worldMatch9.oversFormat = OversFormat.FiftyOvers

worldMatch9.Team1Score = 264

worldMatch9.Team2Score = 261     //team 2 wins here

worldMatch9.ballType = BallType.WhiteBall





var worldMatch10 : WorldCup = WorldCup()

worldMatch10.matchNumber = 10

worldMatch10.matchType = MatchType.quarterfinals

worldMatch10.Team1 = team3

worldMatch10.Team2 = team4

worldMatch10.oversFormat = OversFormat.FiftyOvers

worldMatch10.Team1Score = 202

worldMatch10.Team2Score = 204        //team 4 wins here0

worldMatch10.ballType = BallType.WhiteBall









// Team 1, team 5, team 4, team 2 qualifies to semi finals



var worldMatch11: WorldCup = WorldCup()

worldMatch11.matchNumber = 11

worldMatch11.matchType = MatchType.SemiFinals

worldMatch11.Team1 = team1

worldMatch11.Team2 = team5

worldMatch11.oversFormat = OversFormat.FiftyOvers

worldMatch11.Team1Score = 378

worldMatch11.Team2Score = 377      // team 1 wins here

worldMatch11.ballType = BallType.WhiteBall



var worldMatch12: WorldCup = WorldCup()

worldMatch12.matchNumber = 12

worldMatch12.matchType = MatchType.SemiFinals

worldMatch12.Team1 = team2

worldMatch12.Team2 = team4

worldMatch12.oversFormat = OversFormat.FiftyOvers

worldMatch12.Team1Score = 275

worldMatch12.Team2Score = 256     //team 2 wins here

worldMatch12.ballType = BallType.WhiteBall





//team 1 and team 2 are in finals





var worldMatch13: WorldCup = WorldCup()

worldMatch13.matchNumber = 13

worldMatch13.matchType = MatchType.quarterfinals

worldMatch13.Team1 = team1

worldMatch13.Team2 = team2

worldMatch13.oversFormat = OversFormat.FiftyOvers

worldMatch13.Team1Score = 412

worldMatch13.Team2Score = 411      //team 1 wins here

worldMatch13.ballType = BallType.WhiteBall





// ***************************TEAM 1 WINS THE WORLD CUP**********************************







var t20Match1 : T20WC = T20WC()
t20Match1.matchNumber = 1
t20Match1.matchType = MatchType.PlayOffs
t20Match1.Team1 = team1
t20Match1.Team2 = team2
t20Match1.oversFormat = OversFormat.TwentyOvers
t20Match1.Team1Score = 175
t20Match1.Team2Score = 172
t20Match1.ballType = BallType.RedBall


var t20Match2 : T20WC = T20WC()
t20Match2.matchNumber = 2
t20Match2.matchType = MatchType.PlayOffs
t20Match2.Team1 = team3
t20Match2.Team2 = team4
t20Match2.oversFormat = OversFormat.TwentyOvers
t20Match2.Team1Score = 165
t20Match2.Team2Score = 167
t20Match2.ballType = BallType.RedBall

var t20Match3 : T20WC = T20WC()
t20Match3.matchNumber = 3
t20Match3.matchType = MatchType.PlayOffs
t20Match3.Team1 = team5
t20Match3.Team2 = team6
t20Match3.oversFormat = OversFormat.TwentyOvers
t20Match3.Team1Score = 196
t20Match3.Team2Score = 132
t20Match3.ballType = BallType.RedBall

var t20Match5 : T20WC = T20WC()
t20Match5.matchNumber = 5
t20Match5.matchType = MatchType.PlayOffs
t20Match5.Team1 = team2
t20Match5.Team2 = team3
t20Match5.oversFormat = OversFormat.TwentyOvers
t20Match5.Team1Score = 48
t20Match5.Team2Score = 143
t20Match5.ballType = BallType.RedBall

var t20Match6 : T20WC = T20WC()
t20Match6.matchNumber = 6
t20Match6.matchType = MatchType.SemiFinals
t20Match6.Team1 = team1
t20Match6.Team2 = team4
t20Match6.oversFormat = OversFormat.TwentyOvers
t20Match6.Team1Score = 234
t20Match6.Team2Score = 172
t20Match6.ballType = BallType.RedBall

var t20Match7 : T20WC = T20WC()
t20Match7.matchNumber = 7
t20Match7.tournamentVenue = "lords"
t20Match7.matchType = MatchType.SemiFinals
t20Match7.Team1 = team3
t20Match7.Team2 = team5
t20Match7.oversFormat = OversFormat.TwentyOvers
t20Match7.Team1Score = 155
t20Match7.Team2Score = 127
t20Match7.ballType = BallType.RedBall

var t20Match8 : T20WC = T20WC()
t20Match8.matchNumber = 8
t20Match8.matchType = MatchType.Finals
t20Match8.Team1 = team1
t20Match8.Team2 = team3
t20Match8.oversFormat = OversFormat.TwentyOvers
t20Match8.Team1Score = 165
t20Match8.Team2Score = 163
t20Match8.ballType = BallType.RedBall












print("**************************************************************")
player11.display()


print("**************************************************************")
team6.display()

print("**************************************************************")
t20Match7.display()


print("**************************************************************")
worldMatch8.display()

print("**************************************************************")
umpire03.display()

print("**************************************************************")
coach3.display()





